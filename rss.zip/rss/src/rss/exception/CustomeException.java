package rss.exception;

public class CustomeException extends RuntimeException{

	public CustomeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomeException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public CustomeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CustomeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CustomeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
